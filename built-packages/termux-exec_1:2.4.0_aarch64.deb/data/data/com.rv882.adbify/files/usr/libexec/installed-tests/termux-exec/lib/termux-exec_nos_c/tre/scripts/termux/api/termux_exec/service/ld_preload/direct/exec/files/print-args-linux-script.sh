#!/data/data/com.rv882.adbify/files/usr/bin/sh

echo "$@"
